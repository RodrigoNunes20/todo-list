// Obter elementos da lista de usuarios
const userList = document.getElementById('user-list');

// Obter detalhes do usuario
const userName = document.getElementById('user-name');
const userEmail = document.getElementById('user-email');

// Obter tarefas do usuario
const userTodos = document.querySelector('#user-todos ul');

// Obter elementos de sobreposição de tarefas
const todoOverlay = document.querySelector('.todo-overlay');
const todoTitle = document.getElementById('todo-title');
const todoDescription = document.getElementById('todo-description');
const closeTodoDetailsBtn = document.getElementById('close-todo-details');

// Obter dados de usuario
fetch('https://jsonplaceholder.typicode.com/users')
  .then(response => response.json())
  .then(users => {
    // Lista de usuarios
    users.forEach(user => {
      const li = document.createElement('li');
      li.textContent = user.name;
      li.dataset.userId = user.id;
      userList.appendChild(li);
    });

    // Exibir detalhes de usuario e tarefas
    displayUserDetails(users[0]);
    displayUserTodos(users[0]);

    // Adicionar evento na lista de usuarios
    userList.addEventListener('click', e => {
      const selectedUserId = e.target.dataset.userId;
      const selectedUser = users.find(user => user.id === parseInt(selectedUserId));
      displayUserDetails(selectedUser);
      displayUserTodos(selectedUser);
    });
  });

// Função para exibir detalhes do usuario
function displayUserDetails(user) {
  userName.textContent = user.name;
  userEmail.textContent = user.email;
}

// Função para exibir tarefas do usuario
function displayUserTodos(user) {
  fetch(`https://jsonplaceholder.typicode.com/users/${user.id}/todos`)
    .then(response => response.json())
    .then(todos => {
      // Limpar tarefas atuais
      userTodos.innerHTML = '';

      // Exibir tarefas
      todos.forEach(todo => {
        const li = document.createElement('li');
        li.textContent = todo.title;
        li.dataset.todoId = todo.id;
        if (todo.completed) {
          li.classList.add('completed');
        }
        li.addEventListener('click', () => {
          todoTitle.textContent = todo.title;
          todoDescription.textContent = todo.completed ? 'Completed' : 'Not Completed';
          todoOverlay.classList.add('show');
        });
        userTodos.appendChild(li);
      });
    });
}

// Adicionar clique no botao de fechar detalhes de tarefas
closeTodoDetailsBtn.addEventListener('click', () => {
  todoOverlay.classList.remove('show');
});
