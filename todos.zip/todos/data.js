// Definindo dados dos usuários e suas tarefas
const users = [
    {
      id: 1,
      name: 'João',
      email: 'joao@example.com',
      todos: [
        {
          id: 1,
          title: 'Fazer compras',
          completed: false
        },
        {
          id: 2,
          title: 'Estudar JavaScript',
          completed: true
        }
      ]
    },
    {
      id: 2,
      name: 'Maria',
      email: 'maria@example.com',
      todos: [
        {
          id: 3,
          title: 'Ir à academia',
          completed: true
        },
        {
          id: 4,
          title: 'Preparar jantar',
          completed: false
        }
      ]
    }
  ];
  
  // Exportando os dados para serem utilizados em outros arquivos
  export default users;
  